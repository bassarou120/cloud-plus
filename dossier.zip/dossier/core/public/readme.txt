The public folder is required
